from flask import Flask,render_template
from pynput.keyboard import Key, Listener
import sys
app = Flask(__name__)
def web(infoDic):
    @app.route("/")
    def hello():
        return render_template('''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>News</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body>
{%for i in dict%}
<div class="jumbotron">

        DATE: {{i["DATE"]}}<br />
        TITLE: {{i["TITLE"]}}<br />
    <img src={{i["IMG"]}} width="10%" height="5%"><br />
        INFO:{{i["INFO"]}}<br />
    <p><a href={{i["LINK"]}}>LINK</a></p><br />

        <br />
        <br />
        <br />
    </form>
</div>
{%endfor%}
</body>
</html>''',dict=infoDic.values())

    while True:
        app.run()
        if Listener.key == Key.esc:
            sys.exit()
