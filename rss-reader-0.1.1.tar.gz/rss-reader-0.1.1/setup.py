from setuptools import setup, find_packages
import os
from rss_reader.version import version

def read(fname):
    return open(os.path.join(os.path.dirname(__file__), fname)).read()


setup(
    name='rss-reader',
    version=version,
    author='Ivan Goglev',
    author_email='ivangoglev1998@gmail.com',
    description='A simple CLI rss reader',
    url='https://github.com/goglevivan2/PythonHomework',
    license='MIT',
    packages=find_packages(),
    python_requires='>=3.6',
    keywords='cli rss reader',
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Build Tools',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3.6',
    ],
    entry_points={
        'console_scripts':
            ['rss-reader=rss_reader.__main__:main'],
    }
)
